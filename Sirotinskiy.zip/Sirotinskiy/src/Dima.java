public class Dima {
	public static void main(String[] args) {
		int age = 19;
		System.out.println("Дмитрий " + age);
	}
}